package com.kriperovich.kripsimpleapi;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class KripSimpleAPI {

    // Метод для регистрации предметов
    public static Item registerItem(String id, ItemGroup group) {
        Item item = new Item(new FabricItemSettings().group(group));
        Registry.register(Registries.ITEM, new Identifier("kripsimpleapi", id), item);
        return item;
    }

    // Метод для регистрации блоков
    public static Block registerBlock(String id, Material material, ItemGroup group) {
        Block block = new Block(FabricBlockSettings.of(material).strength(1.5f));
        Registry.register(Registries.BLOCK, new Identifier("kripsimpleapi", id), block);
        Registry.register(Registries.ITEM, new Identifier("kripsimpleapi", id),
                new BlockItem(block, new FabricItemSettings().group(group)));
        return block;
    }

    // Метод для создания новой группы с обложкой
    public static ItemGroup createItemGroup(String groupName, Item groupIcon) {
        return ItemGroup.builder()
            .displayName(groupName)
            .icon(() -> groupIcon)
            .build();
    }
}
